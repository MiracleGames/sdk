#pragma once

typedef const wchar_t* (__stdcall *Func_MessageOpData)(int, const wchar_t*);

typedef Platform::String^ Del_MessageOpData(int messageID, Platform::String^ message);
void Init(Del_MessageOpData* receivedMessageData);

//delegate Platform::String^ Del_MessageOpData(int messageID, Platform::String^ message);
//void Init(Del_MessageOpData^ receivedMessageData);

Func_MessageOpData Fun_NativeDelegate();

void Fun_U3DDelegate(Func_MessageOpData del_U3DDelegate);

Platform::String^ SendMessageToU3D(int messageID, Platform::String^ message);

const wchar_t* __stdcall ReceivedMessageData(int messageID, const wchar_t* message);