#include "pch.h"
#include "InterOpImplement.h"


typedef Func_MessageOpData(*Func_SetFunc_GetNativeDelegate)();
typedef void(*Func_SetFunc_SetU3DDelegate)(Func_MessageOpData);

Func_MessageOpData Del_NativeDelegate;
Func_MessageOpData Del_U3DDelegate;

Del_MessageOpData* ReceivedMessage;

void Init(Del_MessageOpData* receivedMessage)
{
	ReceivedMessage = receivedMessage;
	Del_NativeDelegate = ReceivedMessageData;

	typedef void(*pFunc_Set_GetNativeDelegate)(Func_SetFunc_GetNativeDelegate);
	typedef void(*pFunc_Set_SetU3DDelegate)(Func_SetFunc_SetU3DDelegate);

	HINSTANCE hInst;
	hInst = LoadPackagedLibrary(L"InterOp.dll", 0);

	pFunc_Set_GetNativeDelegate p1 = (pFunc_Set_GetNativeDelegate)GetProcAddress(hInst, "Set_GetNativeDelegate");
	p1(Fun_NativeDelegate);

	pFunc_Set_SetU3DDelegate p2 = (pFunc_Set_SetU3DDelegate)GetProcAddress(hInst, "Set_SetU3DDelegate");
	p2(Fun_U3DDelegate);
}

Func_MessageOpData Fun_NativeDelegate()
{
	return Del_NativeDelegate;
}

void Fun_U3DDelegate(Func_MessageOpData del_U3DDelegate)
{
	Del_U3DDelegate = del_U3DDelegate;
}
Platform::String^ SendMessageToU3D(int messageID, Platform::String^ message)
{
	if (Del_U3DDelegate != nullptr)
	{
		if (message == nullptr)
		{
			return ref new Platform::String(Del_U3DDelegate(messageID, nullptr));
		}
		else
		{
			return ref new Platform::String(Del_U3DDelegate(messageID, message->Data()));
		}
	}
	else
	{
		return nullptr;
	}
}

const wchar_t* __stdcall ReceivedMessageData(int messageID, const wchar_t* message)
{
	Platform::String ^ret = ReceivedMessage(messageID, ref new Platform::String(message));
	if (ret == nullptr)
	{
		return nullptr;
	}
	else
	{
		return ret->Data();
	}
}