﻿//
// MainPage.xaml.cpp
// Implementation of the MainPage class.
//

#include "pch.h"
#include "MainPage.xaml.h"
#include "InterOpImplement.h"
#include<iostream>

using namespace JuiceFresh;

using namespace Concurrency;
using namespace Platform;
using namespace UnityPlayer;
using namespace Windows::ApplicationModel::Activation;
using namespace Windows::Foundation;
using namespace Windows::Storage;
using namespace Windows::System::Threading;
using namespace Windows::UI;
using namespace Windows::UI::Core;
using namespace Windows::UI::Xaml;
using namespace Windows::UI::Xaml::Controls;
using namespace Windows::UI::Xaml::Media;
using namespace Windows::UI::Xaml::Navigation;
using namespace MiracleGames::Advertising::UI;
using namespace Windows::ApplicationModel::Core;


// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409
MainPage^ Instance;
MainPage::MainPage()
{
	m_SplashScreenRemovalEventToken.Value = 0;
	m_OnResizeRegistrationToken.Value = 0;

	InitializeComponent();
	NavigationCacheMode = ::NavigationCacheMode::Required;

	auto appCallbacks = AppCallbacks::Instance;

	bool isWindowsHolographic = false;

#if UNITY_HOLOGRAPHIC
	// If application was exported as Holographic check if the deviceFamily actually supports it,
	// otherwise we treat this as a normal XAML application
	String^ deviceFamily = Windows::System::Profile::AnalyticsInfo::VersionInfo->DeviceFamily;
	isWindowsHolographic = String::CompareOrdinal("Windows.Holographic", deviceFamily) == 0;
#endif

	if (isWindowsHolographic)
	{
		appCallbacks->InitializeViewManager(Window::Current->CoreWindow);
	}
	else
	{
		m_SplashScreenRemovalEventToken = appCallbacks->RenderingStarted += ref new RenderingStartedHandler(this, &MainPage::RemoveSplashScreen);

		appCallbacks->SetKeyboardTriggerControl(this);
		appCallbacks->SetSwapChainPanel(m_DXSwapChainPanel);
		appCallbacks->SetCoreWindowEvents(Window::Current->CoreWindow);
		appCallbacks->InitializeD3DXAML();

		m_SplashScreen = safe_cast<App^>(App::Current)->GetSplashScreen();

		auto dispatcher = CoreWindow::GetForCurrentThread()->Dispatcher;
		ThreadPool::RunAsync(ref new WorkItemHandler([this, dispatcher](IAsyncAction^)
		{
			GetSplashBackgroundColor(dispatcher);
		}));

		OnResize();

		m_OnResizeRegistrationToken = Window::Current->SizeChanged += ref new WindowSizeChangedEventHandler([this](Object^, WindowSizeChangedEventArgs^)
		{
			OnResize();
		});
	}

	Instance = this;
	Init(MainPage::ReceivedMessage);
	InitView();
}

MainPage::~MainPage()
{
	if (m_SplashScreenRemovalEventToken.Value != 0)
	{
		AppCallbacks::Instance->RenderingStarted -= m_SplashScreenRemovalEventToken;
		m_SplashScreenRemovalEventToken.Value = 0;
	}

	if (m_OnResizeRegistrationToken.Value != 0)
	{
		Window::Current->SizeChanged -= m_OnResizeRegistrationToken;
		m_OnResizeRegistrationToken.Value = 0;
	}
}

/// <summary>
/// Invoked when this page is about to be displayed in a Frame.
/// </summary>
/// <param name="e">Event data that describes how this page was reached.  The Parameter
/// property is typically used to configure the page.</param>
void MainPage::OnNavigatedTo(NavigationEventArgs^ e)
{
	m_SplashScreen = safe_cast<SplashScreen^>(e->Parameter);
	OnResize();
}

void MainPage::OnResize()
{
	if (m_SplashScreen != nullptr)
	{
		m_SplashImageRect = m_SplashScreen->ImageLocation;
		PositionImage();
	}
}

void MainPage::PositionImage()
{
	auto inverseScaleX = 1.0f;
	auto inverseScaleY = 1.0f;

	m_ExtendedSplashImage->SetValue(Canvas::LeftProperty, m_SplashImageRect.X * inverseScaleX);
	m_ExtendedSplashImage->SetValue(Canvas::TopProperty, m_SplashImageRect.Y * inverseScaleY);
	m_ExtendedSplashImage->Height = m_SplashImageRect.Height * inverseScaleY;
	m_ExtendedSplashImage->Width = m_SplashImageRect.Width * inverseScaleX;
}

void MainPage::GetSplashBackgroundColor(CoreDispatcher^ dispatcher)
{
	HandleHolder manifestHandle = CreateFile2(L"AppxManifest.xml", GENERIC_READ, FILE_SHARE_READ, OPEN_EXISTING, nullptr);
	if (manifestHandle == nullptr) return;

	LARGE_INTEGER fileSize;
	auto result = GetFileSizeEx(manifestHandle, &fileSize);
	if (result == FALSE) return;

	std::string manifest;
	manifest.resize(static_cast<size_t>(fileSize.QuadPart));

	DWORD bytesRead;
	result = ReadFile(manifestHandle, &manifest[0], static_cast<DWORD>(fileSize.QuadPart), &bytesRead, nullptr);
	if (result == FALSE) return;
	if (bytesRead != fileSize.QuadPart) return;

	auto idx = manifest.find("SplashScreen");

	if (idx == std::string::npos)
		return;

	manifest = manifest.substr(idx);
	idx = manifest.find("BackgroundColor");

	if (idx == std::string::npos)
		return;

	manifest = manifest.substr(idx);
	idx = manifest.find("\"");

	if (idx == std::string::npos || idx + 2 > manifest.length())
		return;

	manifest = manifest.substr(idx + 1); // also remove quote and # char after it
	idx = manifest.find("\"");

	if (idx == std::string::npos)
		return;

	manifest = manifest.substr(0, idx);

	int value = 0;
	bool transparent = false;
	if (manifest == "transparent")
		transparent = true;
	else if (manifest[0] == '#')
	{
		// color value has leading #
		value = std::stoi(manifest.substr(1), 0, 16);
	}
	else
		return; // we reach this point if values like 'red', 'blue' etc are used Unity does not set such, so you probably want to use hardcoded value here too

	uint8_t r = static_cast<uint8_t>(value >> 16);
	uint8_t g = static_cast<uint8_t>((value & 0x0000FF00) >> 8);
	uint8_t b = static_cast<uint8_t>(value & 0x000000FF);

	dispatcher->RunAsync(CoreDispatcherPriority::High, ref new DispatchedHandler([this, r, g, b, transparent]
	{
		Color color;
		color.R = r;
		color.G = g;
		color.B = b;
		color.A = transparent ? 0x00 : 0xFF;
		m_ExtendedSplashGrid->Background = ref new SolidColorBrush(color);
	}));
}

void MainPage::RemoveSplashScreen()
{
	uint32_t index;

	if (m_DXSwapChainPanel->Children->IndexOf(m_ExtendedSplashGrid, &index))
		m_DXSwapChainPanel->Children->RemoveAt(index);

	if (m_OnResizeRegistrationToken.Value != 0)
	{
		Window::Current->SizeChanged -= m_OnResizeRegistrationToken;
		m_OnResizeRegistrationToken.Value = 0;
	}
}

Windows::UI::Xaml::Automation::Peers::AutomationPeer^ MainPage::OnCreateAutomationPeer()
{
	return AppCallbacks::CreateAutomationPeer(this);
}

// ****************
// MiracleGames.INavigationCommand相关属性说明。
// ParentContainer属性: 影响积分墙, 商店, 登录界面在应用中的显示, 当设置了ParentContainer属性, 则积分墙, 商店, 登录界面将会在ParentContainer中打开。
// Type属性: 
//     MiracleGames.NavigationType.InApp: 积分墙, 商店, 登录界面将在当前应用中打开。
//     MiracleGames.NavigationType.InSystem: 设置积分墙, 商店, 登录界面将在系统默认浏览器中打开。
// CanHandleBackRequest属性: 设置积分墙, 商店, 登录界面是否能够处理后退请求, 默认值为True.
//
// 对于Xaml+Direct3D的应用, 因为从Direct3D导航到新页面时开销较大, 所以请设置ParentContainer属性为页面中的某一个控件。
// ****************

// 登录或切换账号
void MainPage::SignInOrSignOut()
{
	MiracleGames::AuthenticationNavigationCommand^ command = ref new MiracleGames::AuthenticationNavigationCommand();
	// 指定是在当前应用还是在系统浏览器中打开
	//command->Type = this->GetNavigationType();
	// 指定界面在那个容器中打开
	//command->ParentContainer = this->GetContainer();
	// 设置是否允许处理后退请求
	//command->CanHandleBackRequest = cbCanHandleBackRequest->IsChecked->Value;
	// 登录界面背景遮挡层是否可见
	//command->IsBackgroundLayerVisible = true;
	// 登录界面背景遮挡层颜色
	//command->BackgroundLayerColor = Windows::UI::ColorHelper::FromArgb(200, 255, 255, 255);

	auto authTask = Concurrency::create_task(MiracleGames::User::AuthenticationManager::AuthenticateAsync(command));
	authTask.then([=](MiracleGames::IAsyncResult^ result)
	{
		if (result->IsCompleted)
		{
			// 标识用户是否已经登录。
			bool isSignedIn = MiracleGames::User::AuthenticationManager::UserProfile->IsSignedIn;
			//MainPage::UserProfile->UpdateProfile(MiracleGames::User::AuthenticationManager::UserProfile);
		}
	});
}

// 打开积分墙
void MainPage::OpenIntegralWall()
{
	MiracleGames::NavigationCommand^ command = ref new MiracleGames::NavigationCommand();
	//command->Type = this->GetNavigationType();
	//command->ParentContainer = this->GetContainer();
	//command->CanHandleBackRequest = cbCanHandleBackRequest->IsChecked->Value;
	// 备注信息 (与奖励中的Comment属性对应), 可以在备注中包含用户Id等信息来确定接收奖励的用户。
	// 如果当前应用不给予奖励, 不用设置该属性。
	command->Comment = "UserId=1234567&DeviceId=abcd";
	MiracleGames::Advertising::AdvertisingManager::OpenIntegralWall(command); // 打开积分墙
																			  // ******
																			  //如果不含备注信息, 可直接使用如下方法:
																			  //MiracleGames::Advertising::AdvertisingManager::OpenIntegralWall();
}

// 打开商店
void MainPage::OpenStore()
{
	MiracleGames::NavigationCommand^ command = ref new MiracleGames::NavigationCommand();
	//command->Type = this->GetNavigationType();
	//command->ParentContainer = this->GetContainer();
	//command->CanHandleBackRequest = cbCanHandleBackRequest->IsChecked->Value;
	// 备注信息 (与资产中的Comment属性对应), 可以在备注中包含用户Id等信息来确定接收资产的用户。
	command->Comment = "UserId=1234567&DeviceId=abcd";
	MiracleGames::Payment::PaymentManager::OpenStore(command); // 打开商店
															   // ******
															   //如果不含备注信息, 可直接使用如下方法:
															   //MiracleGames::Payment::PaymentManager::OpenStore();

}

// 直接购买指定的商品
// goodsKey: 商品Key, 创建商品时由MiracleGames生成 --MG支付
Platform::String^ MainPage::PurchaseGoodsMG(Platform::String^ goodsKey, Platform::String^ message)
{
	//TODO 无需支付直接发货
	//SendMessageToU3D(5, message);
	//return "1";

	OutputDebugStringW((goodsKey + message)->Data());

	MiracleGames::StoreNavigationCommand^ command = ref new MiracleGames::StoreNavigationCommand();

	command->Comment = message->ToString();
	// 可选, 商品Key, 再创建商品时由MiracleGames生成, 用于唯一标识一个商品
	command->DigitalGoodsKey = goodsKey;
	// 可选, 商品数量, 默认值为1
	command->DigitalGoodsCount = 1;
	// 可选, 服务器回调地址Id, 在设置回调地址时由MiracleGames生成, 开发者可以设置多个回调地址, 该笔交易将会给指定Id的回调地址发起支付成功的回调
	// 如果设置了回调地址, 但未指定id, 即CallbackId=null, 将使用默认回调地址
	// 如果指定了Id, 但该Id不存在, 将不能支付
	// 如果不使用服务器回调, 请忽略该属性。
	//command->CallbackId = "219db71f-434d-4706-9fa5-0792bbaec9a7";
	command->IsOnlyShowMSPay = false;
	MiracleGames::Payment::PaymentManager::OpenStore(command);
	return "1";
}

// 直接购买指定的商品
// goodsKey: 商品Key, 创建商品时由MiracleGames生成 --微软支付
Platform::String^ MainPage::PurchaseGoodsMicrosoft(Platform::String^ goodsKey, Platform::String^ message)
{
	//TODO 无需支付直接发货
	//SendMessageToU3D(5, message);
	//return "1";

	OutputDebugStringW((goodsKey+ message)->Data());

	MiracleGames::StoreNavigationCommand^ command = ref new MiracleGames::StoreNavigationCommand();

	//command->CanHandleBackRequest = true;

	//command->Type = this->GetNavigationType();
	//command->ParentContainer = this->GetContainer();
	//command->CanHandleBackRequest = cbCanHandleBackRequest->IsChecked->Value;
	command->Comment = message->ToString();
	// 可选, 商品Key, 再创建商品时由MiracleGames生成, 用于唯一标识一个商品
	command->DigitalGoodsKey = goodsKey;
	// 可选, 商品数量, 默认值为1
	command->DigitalGoodsCount = 1;
	// 可选, 服务器回调地址Id, 在设置回调地址时由MiracleGames生成, 开发者可以设置多个回调地址, 该笔交易将会给指定Id的回调地址发起支付成功的回调
	// 如果设置了回调地址, 但未指定id, 即CallbackId=null, 将使用默认回调地址
	// 如果指定了Id, 但该Id不存在, 将不能支付
	// 如果不使用服务器回调, 请忽略该属性。
	//command->CallbackId = "219db71f-434d-4706-9fa5-0792bbaec9a7";
	command->IsOnlyShowMSPay = true;
	MiracleGames::Payment::PaymentManager::OpenStore(command);
	return "1";
}

Platform::String^MainPage::F_OpenStore()
{
	this->OpenStore();
	return "1";
}
Platform::String^MainPage::F_Login()
{
	MiracleGames::AuthenticationNavigationCommand^ command = ref new MiracleGames::AuthenticationNavigationCommand();
	// 指定是在当前应用还是在系统浏览器中打开
	//command->Type = this->GetNavigationType();
	// 指定界面在那个容器中打开
	//command->ParentContainer = Instance->m_DXSwapChainPanel;
	// 设置是否允许处理后退请求
	//command->CanHandleBackRequest = cbCanHandleBackRequest->IsChecked->Value;
	// 登录界面背景遮挡层是否可见
	//command->IsBackgroundLayerVisible = true;
	// 登录界面背景遮挡层颜色
	//command->BackgroundLayerColor = Windows::UI::ColorHelper::FromArgb(200, 255, 255, 255);
	auto authTask = Concurrency::create_task(MiracleGames::User::AuthenticationManager::AuthenticateAsync(command));
	authTask.then([=](MiracleGames::IAsyncResult^ result)
	{
		if (result->IsCompleted)
		{
			// 标识用户是否已经登录。
			bool isSignedIn = MiracleGames::User::AuthenticationManager::UserProfile->IsSignedIn;
			//MainPage::UserProfile->UpdateProfile(MiracleGames::User::AuthenticationManager::UserProfile);
			if (isSignedIn)
				SendMessageToU3D(4, MiracleGames::User::AuthenticationManager::UserProfile->Id + "^" + MiracleGames::User::AuthenticationManager::UserProfile->Token);
			////MG登陆结果的返回值
			else
			{
				SendMessageToU3D(4, nullptr);
				F_Login();
			}
		}
	});

	

	return "1";
}


//分割字符串方法
void SplitString(const std::string& s, std::vector<std::string>& v, const std::string& c)
{
	std::string::size_type pos1, pos2;
	pos2 = s.find(c);
	pos1 = 0;
	while (std::string::npos != pos2)
	{
		v.push_back(s.substr(pos1, pos2 - pos1));

		pos1 = pos2 + c.size();
		pos2 = s.find(c, pos1);
	}
	if (pos1 != s.length())
		v.push_back(s.substr(pos1));
}
std::wstring stows(std::string s)
{
	std::wstring ws;
	ws.assign(s.begin(), s.end());
	return ws;
}

Platform::String^ stops(std::string s)
{
	return ref new Platform::String(stows(s).c_str());
}

std::string wstos(std::wstring ws)
{
	std::string s;
	s.assign(ws.begin(), ws.end());
	return s;
}

std::string pstos(Platform::String^ ps)
{
	return wstos(std::wstring(ps->Data()));
}

Platform::String^ GetGoodsKey(String^ gemName)
{
	//JuiceFresh
	//	F34ED1455487650 = 0.99
	//	50318C8886A3C71 = 4.99
	//	2EF9BDF3E9329C2 = 9.99
	//	0801BEA9C5266AE = 14.99

	//HappyJuiceFresh
	//	6C2F6D8264E16A3 = 0.99
	//	0AD108781DCE2D4 = 4.99
	//	B2FE98577955485 = 9.99
	//	3D641AA78CF0831 = 14.99

	//JuiceFresh-HD
	//	8B1C9DF91A1DEA4 = 0.99
	//	993A2F746569436 = 4.99
	//	47B862AC65F4723 = 9.99
	//	312A0D692FC0F37 = 14.99

	//Happy Juice Fresh HD
	//	2B90A2DBE27BA17 = 0.99
	//	16F78423DD7012C = 4.99
	//	C7575A0CB55FDDB = 9.99
	//	FF65C26BBC7696A = 14.99




	//不良人 30  0808D356C48A8A0
	//不良人 328	DCCFB757D9B97D8

	if (gemName == "Pack1")
	{
		return "2B90A2DBE27BA17";
	}
	else if (gemName == "Pack2")
	{
		return "16F78423DD7012C";
	}
	else if (gemName == "Pack3")
	{
		return "C7575A0CB55FDDB";
	}
	else if (gemName == "Pack4")
	{
		return "FF65C26BBC7696A";
	}
}

String^ MainPage::ReceivedMessage(int messageID, String^ message)
{
	String^ retV = message;
	std::vector<std::string> strVec;
	std::string input;
	String^ goodsKey;
	String^ comment;
	switch (messageID)
	{
	case 1:
		return Instance->F_GetAppVersion();
	case 2:
		//把消息分割为goodsKey和Comment --MG支付
		input = wstos(std::wstring(retV->Data()));
		SplitString(input, strVec, "^");
		goodsKey = stops(strVec[0]);
		comment = stops(strVec[1]);
		
		return Instance->PurchaseGoodsMG(GetGoodsKey(goodsKey), comment);
	//case 3:
		//return Instance->F_Login();
	case 4:
		return Instance->F_CallNative();
	case 5://显示插屏广告
		 return Instance->MainScreen_AD();

	case 6://显示横幅广告
		return Instance->MainScreen_Binner();

	case 7://显示微软支付
		   //把消息分割为goodsKey和Comment
		input = wstos(std::wstring(retV->Data()));
		SplitString(input, strVec, "^");
		goodsKey = stops(strVec[0]);
		comment = stops(strVec[1]);
		return Instance->PurchaseGoodsMicrosoft(GetGoodsKey(goodsKey), comment);
	//case 8://显示全屏（开屏）广告
		//return Instance->MainScreen_FullScreenAd();
	//case 9://强制推荐
		//return Instance->MainScreen_ForceAd();
	default:
		break;
	}

	return retV;
}

Platform::String^ MainPage::MainScreen_AD()   //MG AD
{
	Windows::UI::Core::CoreWindow^ wnd = Windows::ApplicationModel::Core::CoreApplication::MainView->CoreWindow;

	wnd->Dispatcher->RunAsync(
		Windows::UI::Core::CoreDispatcherPriority::Normal,
		ref new Windows::UI::Core::DispatchedHandler([]()
	{
		//插屏：AdUnitId：Juice Fresh 41C02D0095 ; HappyJuiceFresh 7FC4E70F7F ; JuiceFresh-HD 2B9F27C8E1
		//HappyJuiceFresh HD  7FEFEFC8FC
		MiracleGames::Advertising::UI::AdControl^ ad = ref new MiracleGames::Advertising::UI::AdControl("7FEFEFC8FC","7FEFEFC8FC",true);
		//ad->VerticalAlignment = Windows::UI::Xaml::VerticalAlignment::Center;
		//ad->HorizontalAlignment = Windows::UI::Xaml::HorizontalAlignment::Center;
		ad->CloseIconVisibility = Windows::UI::Xaml::Visibility::Visible;
		Grid::SetRowSpan(ad, 10);
		Instance->m_DXSwapChainPanel->Children->Append(ad);
	}));
		return "";
}

Platform::String^ MainPage::MainScreen_Binner()   //MG Banner
{
	Windows::UI::Core::CoreWindow^ wnd = Windows::ApplicationModel::Core::CoreApplication::MainView->CoreWindow;

	wnd->Dispatcher->RunAsync(
		Windows::UI::Core::CoreDispatcherPriority::Normal,
		ref new Windows::UI::Core::DispatchedHandler([]()
	{
		// 横幅：AdUnitId: Juice Fresh C6A3F34277 ; HappyJuiceFresh 66BEA598EA ; JuiceFresh-HD 57AD9521B6
		//HappyJuiceFresh HD  9E504BDD9A
		MiracleGames::Advertising::UI::AdControl^ ad = ref new MiracleGames::Advertising::UI::AdControl("9E504BDD9A", "9E504BDD9A", true);
		//ad->VerticalAlignment = Windows::UI::Xaml::VerticalAlignment::Bottom;
		//ad->HorizontalAlignment = Windows::UI::Xaml::HorizontalAlignment::Center;
		ad->CloseIconVisibility = Windows::UI::Xaml::Visibility::Visible;
		Grid::SetRowSpan(ad, 10);
		Instance->m_DXSwapChainPanel->Children->Append(ad);

	}));

	return "";
}

Platform::String^ MainPage::MainScreen_FullScreenAd()   //MG FullScreenAd
{
	Windows::UI::Core::CoreWindow^ wnd = Windows::ApplicationModel::Core::CoreApplication::MainView->CoreWindow;

	wnd->Dispatcher->RunAsync(
		Windows::UI::Core::CoreDispatcherPriority::Normal,
		ref new Windows::UI::Core::DispatchedHandler([]()
	{
		// 弹窗：AdUnitId: Juice Fresh F2A440E1C7   JuiceFresh-HD 4EDBCA0DD8
		//全屏（开屏） HappyJuiceFresh HD C45C3D27AA
		MiracleGames::Advertising::UI::AdControl^ ad = ref new MiracleGames::Advertising::UI::AdControl("C45C3D27AA", "C45C3D27AA", true);
		
		ad->AdClosed += ref new Windows::Foundation::EventHandler<Windows::UI::Xaml::RoutedEventArgs ^>(Instance, &MainPage::FullScreenAd_Close);
		
		
		//不要控制布局**********
		//ad->VerticalAlignment = Windows::UI::Xaml::VerticalAlignment::Bottom;
		//ad->HorizontalAlignment = Windows::UI::Xaml::HorizontalAlignment::Right;
		ad->CloseIconVisibility = Windows::UI::Xaml::Visibility::Visible;
		Grid::SetRowSpan(ad, 10);
		Instance->m_DXSwapChainPanel->Children->Append(ad);

	}));

	return "";
}
static bool isLogining = false;
void MainPage::FullScreenAd_Close(Platform::Object ^sender, Windows::UI::Xaml::RoutedEventArgs^ e)
{
	if (isLogining == false)
	{
		isLogining = true;
		Instance->F_Login();
	}
	
}

Platform::String^ MainPage::MainScreen_ForceAd()   //MG forceAd
{
	Windows::UI::Core::CoreWindow^ wnd = Windows::ApplicationModel::Core::CoreApplication::MainView->CoreWindow;

	wnd->Dispatcher->RunAsync(
		Windows::UI::Core::CoreDispatcherPriority::Normal,
		ref new Windows::UI::Core::DispatchedHandler([]()
	{
		// 强制推荐 HappyJuiceFresh HD CE019620DD
		MiracleGames::Advertising::UI::AdControl^ ad = ref new MiracleGames::Advertising::UI::AdControl("CE019620DD", "CE019620DD", true);
		//ad->VerticalAlignment = Windows::UI::Xaml::VerticalAlignment::Bottom;
		//ad->HorizontalAlignment = Windows::UI::Xaml::HorizontalAlignment::Right;
		ad->CloseIconVisibility = Windows::UI::Xaml::Visibility::Visible;
		Grid::SetRowSpan(ad, 10);
		Instance->m_DXSwapChainPanel->Children->Append(ad);

	}));

	return "";
}



void MainPage::InitView()
{
	//C_Button_InvokeU3D->Tapped += ref new Windows::UI::Xaml::Input::TappedEventHandler([this](Platform::Object^ sender, Windows::UI::Xaml::Input::TappedRoutedEventArgs^ e)
	//{
	//	String^ retV = SendMessageToU3D(3, C_TextBox_Input->Text + ":"); //+ InterOpHelper::GuidHelper::GetNewGuid().ToString());
	//});
}

Platform::String^ MainPage::F_GetAppVersion()
{
	Windows::ApplicationModel::Package ^cp = Windows::ApplicationModel::Package::Current;
	Windows::ApplicationModel::PackageVersion pv = cp->Id->Version;

	String ^ret = pv.Major.ToString() + "." + pv.Minor.ToString() + "." + pv.Build.ToString() + "." + pv.Revision.ToString();

	return ret;
}

Platform::String^ MainPage::F_CallNative()
{

	if (MiracleGames::ApplicationManager::SetupCompletedSuccessfully)
	{
		SendMessageToU3D(1, "true" + "^" + "");
		Instance->MainScreen_FullScreenAd();
		Instance->MainScreen_ForceAd();
		return "123";
	}
	//// 请传入正确的AppKey JuiceFresh EA2CC7E7BE  ; HappyJuiceFresh 9AF291E5DD ; Juice Fresh-HD  7D1A5E38C8 ;
	//auto initTask = Concurrency::create_task(MiracleGames::ApplicationManager::SetupAsync("EA2CC7E7BE"));
	//initTask.then([](MiracleGames::IAsyncResult^ result)
	//{
	//	OutputDebugStringW(result->ToString()->Data());
	//	SendMessageToU3D(1, result->IsCompleted.ToString() + "^" + ""); //MG初始化结果的返回值
	//																			  //MainPage::UserProfile->UpdateProfile(MiracleGames::User::AuthenticationManager::UserProfile);
	//																			  //Windows::UI::Popups::MessageDialog^ dialog = ref new Windows::UI::Popups::MessageDialog(result->ToString());
	//																			  //dialog->ShowAsync();
	//});
	return "123";

}

