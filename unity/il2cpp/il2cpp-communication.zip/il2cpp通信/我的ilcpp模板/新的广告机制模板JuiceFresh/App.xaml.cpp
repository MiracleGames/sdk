﻿//
// App.xaml.cpp
// Implementation of the App class.
//

#include "pch.h"
#include "MainPage.xaml.h"
#include "UnityGenerated.h"
#include "InterOpImplement.h"

using namespace JuiceFresh;

using namespace Platform;
using namespace UnityPlayer;
using namespace Windows::ApplicationModel::Activation;
using namespace Windows::UI::ViewManagement;
using namespace Windows::UI::Xaml;
using namespace Windows::UI::Xaml::Controls;
using namespace Windows::UI::Xaml::Interop;

// The Blank Application template is documented at http://go.microsoft.com/fwlink/?LinkId=402347&clcid=0x409

/// <summary>
/// Initializes the singleton application object.  This is the first line of authored code
/// executed, and as such is the logical equivalent of main() or WinMain().
/// </summary>
App::App()
{
	InitializeComponent();
	SetupOrientation();
	m_AppCallbacks = ref new AppCallbacks();

	//**********
	// 注册资产变更事件, 当前应用的资产发生变更时, 触发该事件。
	// 如果当前应用不添加支付功能或使用支付服务器回调, 不用注册该事件。
	MiracleGames::Payment::PaymentManager::AssetsChanged +=
		ref new Windows::Foundation::EventHandler<MiracleGames::Payment::AssetsChangedEventArgs ^>(this, &App::OnAssetsChanged);
	//注册MG支付面板关闭事件，当MG支付浏览器关闭时，触发该事件。
	// 如果当前应用不添加支付功能或使用支付服务器回调, 不用注册该事件。
	MiracleGames::Payment::PaymentManager::StoreClosed +=
		ref new Windows::Foundation::EventHandler<Platform::Object ^>(this, &App::OnStoreClosed);

	//注册退屏广告事件，当推出游戏时，触发该事件
	this->Suspending += ref new Windows::UI::Xaml::SuspendingEventHandler(this, &App::App_Suspending);

}

//退屏广告 
void App::App_Suspending(Platform::Object ^sender, Windows::ApplicationModel::SuspendingEventArgs ^e)
{
	int a=MiracleGames::Advertising::AdvertisingManager::ExistAd();
}


/// <summary>
/// Invoked when the application is launched normally by the end user.	Other entry points
/// will be used such as when the application is launched to open a specific file.
/// </summary>
/// <param name="e">Details about the launch request and process.</param>
void App::OnLaunched(LaunchActivatedEventArgs^ e)
{
	m_SplashScreen = e->SplashScreen;
	InitializeUnity(e->Arguments);
}

/// <summary>
/// Invoked when application is launched through protocol.
/// Read more - http://msdn.microsoft.com/library/windows/apps/br224742
/// </summary>
/// <param name="args"></param>
void App::OnActivated(IActivatedEventArgs^ args)
{
	String^ appArgs = "";

	if (args->Kind == ActivationKind::Protocol)
	{
		auto eventArgs = safe_cast<ProtocolActivatedEventArgs^>(args);
		m_SplashScreen = eventArgs->SplashScreen;
		appArgs += String::Concat("Uri={0}", eventArgs->Uri->AbsoluteUri);
	}

	InitializeUnity(appArgs);
}

/// <summary>
/// Invoked when application is launched via file
/// Read more - http://msdn.microsoft.com/library/windows/apps/br224742
/// </summary>
/// <param name="args"></param>
void App::OnFileActivated(FileActivatedEventArgs^ args)
{
	String^ appArgs = "File=";

	m_SplashScreen = args->SplashScreen;

	bool firstFileAdded = false;

	for (auto file : args->Files)
	{
		if (firstFileAdded)
		{
			appArgs += ";";
		}
		else
		{
			firstFileAdded = true;
		}

		appArgs += file->Path;
	}

	InitializeUnity(appArgs);
}

void App::InitializeUnity(String^ args)
{
	ApplicationView::GetForCurrentView()->SuppressSystemOverlays = true;

	m_AppCallbacks->SetAppArguments(args);
	auto rootFrame = safe_cast<Frame^>(Window::Current->Content);

	// Do not repeat app initialization when the Window already has content,
	// just ensure that the window is active
	if (rootFrame == nullptr && !m_AppCallbacks->IsInitialized())
	{
		rootFrame = ref new Frame();
		Window::Current->Content = rootFrame;
#if !UNITY_HOLOGRAPHIC
		Window::Current->Activate();
#endif

		rootFrame->Navigate(TypeName(MainPage::typeid));
	}

	Window::Current->Activate();
	Init();
}

void App::Init()
{
	if (MiracleGames::ApplicationManager::SetupCompletedSuccessfully)
	{
		return;
	}
	// 请传入正确的AppKey  JuiceFresh EA2CC7E7BE  ; HappyJuiceFresh 9AF291E5DD ; Juice Fresh-HD  7D1A5E38C8 
	//Happy Juice Fresh HD  60F0C13090
	auto initTask = Concurrency::create_task(MiracleGames::ApplicationManager::SetupAsync("60F0C13090"));
	initTask.then([](MiracleGames::IAsyncResult^ result)
	{
		OutputDebugStringW(result->ToString()->Data());
		//SendMessageToU3D(1, result->IsCompleted.ToString() + "^" + ""); //MG初始化结果的返回值
																				  //MainPage::UserProfile->UpdateProfile(MiracleGames::User::AuthenticationManager::UserProfile);
																				  //Windows::UI::Popups::MessageDialog^ dialog = ref new Windows::UI::Popups::MessageDialog(result->ToString());
																				  //dialog->ShowAsync();
	});
}

void App::SetupOrientation()
{
	Unity::SetupDisplay();
}

void App::OnAssetsChanged(Platform::Object ^sender, MiracleGames::Payment::AssetsChangedEventArgs ^args)
{
	auto num = args->GetAssetsCount();
	for (int i = 0; i < num; i++)
	{
		auto item = args->GetAssetElementAt(i);

		//Windows::UI::Popups::MessageDialog^ dialog = ref new Windows::UI::Popups::MessageDialog(item->Goods->Name->ToString());
		//dialog->ShowAsync();

		// 购买的商品数量: item.Count;
		// 购买的商品: item.Goods
		// 商品名称: item.Goods.Name
		// 商品Tag (创建商品时设置的自定义信息): item.Goods.Tag
		// 备注 (与打开商店时传入的Comment参数对应): item.Comment
		// 例如: 可以通过备注确定该资产所属的用户(备注中包含用户Id等可以唯一标识用户的信息)

		// 履行资产，通知Miracle Games服务器，指示已履行该商品的交易。 (该方法返回成功后才能将资产给予用户)
		// 可以先通过备注先判断该资产是否属于当前用户，然后再履行资产
		auto useTask = Concurrency::create_task(item->ReportFulfillmentAsync());
		useTask.then([](MiracleGames::IAsyncResult^ result)
		{
			if (result->IsCompleted) // 履行资产成功，把资产中对应商品给用户
			{
				// 在下面添加获取资产的代码
				// 注意: 不要遗漏了购买的数量
				// 例如: 获取的金币数量为amount
				// auto amount = item->Count * _wtoi(item->Goods->Tag->Data());
			}
		});

		///////************
		//SendMessageToU3D(5, item->ToString());
		SendMessageToU3D(5, item->Comment);//MG购买结果的返回值

	}

}


void App::OnStoreClosed(Platform::Object ^sender, Platform::Object ^senders)
{
	//2017/11/3  ---韩景宁
	//关闭窗口时，进行一次资源检测。查询是否有订单支付完成。
	MiracleGames::Payment::PaymentManager::UpdateAssetsAsync();
	//关闭窗口
	SendMessageToU3D(6, "StoreClosed");
}
