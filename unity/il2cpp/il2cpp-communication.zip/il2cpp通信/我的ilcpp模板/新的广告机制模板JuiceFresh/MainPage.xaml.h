﻿//
// MainPage.xaml.h
// Declaration of the MainPage class.
//

#pragma once

#include "MainPage.g.h"

namespace JuiceFresh
{
	/// <summary>
	/// An empty page that can be used on its own or navigated to within a Frame.
	/// </summary>
	public ref class MainPage sealed
	{
	protected:
		virtual void OnNavigatedTo(Windows::UI::Xaml::Navigation::NavigationEventArgs^ e) override;
		virtual Windows::UI::Xaml::Automation::Peers::AutomationPeer^ OnCreateAutomationPeer() override;

		void SignInOrSignOut();

		void OpenIntegralWall();

		void OpenStore();

		Platform::String ^ PurchaseGoodsMG(Platform::String ^ goodsKey, Platform::String ^ message);

		Platform::String ^ PurchaseGoodsMicrosoft(Platform::String ^ goodsKey, Platform::String ^ message);

		Platform::String ^ F_OpenStore();

		Platform::String ^ F_Login();


		static Platform::String^ ReceivedMessage(int messageID, Platform::String^ message);

		Platform::String^ MainScreen_AD();

		Platform::String^ MainScreen_Binner();

		Platform::String ^ MainScreen_FullScreenAd();

		

		void FullScreenAd_Close(Platform::Object ^ sender, Windows::UI::Xaml::RoutedEventArgs ^ r);

		

		

		void InitView();

		Platform::String ^ F_GetAppVersion();

		Platform::String ^ F_CallNative();


	public:
		MainPage();
		static Platform::String ^ MainScreen_ForceAd();

	private:
		Windows::ApplicationModel::Activation::SplashScreen^ m_SplashScreen;
		Windows::Foundation::Rect m_SplashImageRect;
		Windows::Foundation::EventRegistrationToken m_SplashScreenRemovalEventToken;
		Windows::Foundation::EventRegistrationToken m_OnResizeRegistrationToken;

		~MainPage();

		void OnResize();
		void PositionImage();
		void GetSplashBackgroundColor(Windows::UI::Core::CoreDispatcher^ dispatcher);
		void RemoveSplashScreen();
	};
}
