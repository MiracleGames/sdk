﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class V_Main : MonoBehaviour
{
    public InputField C_InputField_SendToNative;

    public InputField C_InputField_ReceiveFromNative;

    public InputField C_InputField_ReceiveFromNative2;


    public static V_Main Instance;
    private void Start()
    {
        if (Instance == null)
        {
            Instance = this;

            //注册接收消息的处理函数
            InterOp.Init(Fun_OnReceiveNativeMessage);
        }
    }


    private string Fun_OnReceiveNativeMessage(int messageID, string message)
    {
        string retV = null;

        switch ((InterOpCommand)messageID)
        {
            case InterOpCommand.GetAppVersion:
                break;
            case InterOpCommand.CallTest1:
                break;
            case InterOpCommand.CallTest2:
                return F_ReceiveFromNative(message);
        }

        return retV;
    }





    public void F_GetAppVersion()
    {
        //发送消息给原生代码，并得到一个返回值
        //注意，线程是U3D的线程
        C_InputField_ReceiveFromNative.text = InterOp.SendMessageToNative((int)InterOpCommand.GetAppVersion, null);
    }


    public void F_GetAppVersion_TestOtherThread()
    {
        ActionHelper.Instance.QueueOnOtherThread((obj) =>
        {
            string retV = InterOp.SendMessageToNative((int)InterOpCommand.GetAppVersion, null);

            ActionHelper.Instance.QueueOnU3DThread((obj2) =>
            {
                C_InputField_ReceiveFromNative.text = retV;
            }, null);
        }, null);
    }


    public void F_CallNative()
    {
        //发送消息给原生代码，并得到一个返回值
        //注意，线程是U3D的线程
        C_InputField_ReceiveFromNative.text = "Return from native: " + InterOp.SendMessageToNative((int)InterOpCommand.CallTest1, C_InputField_SendToNative.text);
    }


    private string F_ReceiveFromNative(string message)
    {
        //做一些处理。
        string retV = "U3D return:" + message.GetHashCode().ToString();

        //注意，方法是在原生UI线程中执行的，所以这里需要转到U3D中运行
        ActionHelper.Instance.QueueOnU3DThread((obj) =>
        {
            C_InputField_ReceiveFromNative2.text = message;
        }, null);

        return retV;
    }
}
