﻿using UnityEngine;
using System.Collections;

public enum InterOpCommand : byte
{
    RunOnOtherThread = 0,

    GetAppVersion = 1,

    CallTest1 = 2,

    CallTest2 = 3,
}
