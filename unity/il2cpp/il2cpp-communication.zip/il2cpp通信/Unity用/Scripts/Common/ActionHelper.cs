﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;

public class ActionHelper : MonoBehaviour
{
    public static ActionHelper Instance;

    private int Locker;

    private int Count;
    private Queue<ParametricAction> TheActions = new Queue<ParametricAction>(13);

    static ActionHelper()
    {

    }

    public int GetCount()
    {
        return Count;
    }


    // Use this for initialization
    void Start()
    {
        Instance = this;
    }

    // Update is called once per frame
    void Update()
    {
        ParametricAction? nowAction = null;

        if (Count > 0 && Interlocked.CompareExchange(ref Locker, 1, 0) == 0)  //能够从0换成1
        {
            try
            {
                if (Count > 0)
                {
                    nowAction = TheActions.Dequeue();
                    Count--;
                    
                }
            }
            finally
            {
                Locker = 0;
            }
        }

        if (nowAction != null)
        {
            nowAction.Value.TheAction(nowAction.Value.Parameter);
        }
    }


    public void QueueOnU3DThread(Action<object> action, object obj)
    {
        Redo:
        if (Interlocked.CompareExchange(ref Locker, 1, 0) == 0)  //能够从0换成1
        {
            TheActions.Enqueue(new ParametricAction(action, obj));
            Count++;
            Locker = 0;
        }
        else  //模拟CPU自旋等待
        {
            goto Redo;
        }
    }


    public void QueueOnOtherThread(Action<object> action, object obj)
    {
        System.Threading.ThreadPool.QueueUserWorkItem(new System.Threading.WaitCallback((o) =>
        {
            action(obj);
        }));
    }


    public static void ThreadWait(int timeMS)
    {
        //微软SB
#if UNITY_WSA && !UNITY_EDITOR
        new System.Threading.ManualResetEvent(false).WaitOne(timeMS);
#else
        System.Threading.Thread.Sleep(timeMS);
#endif
    }
}


public struct ParametricAction
{
    public Action<object> TheAction;

    public object Parameter;

    public ParametricAction(Action<object> action, object parameter)
    {
        TheAction = action;
        Parameter = parameter;
    }
}
