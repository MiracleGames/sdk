﻿using UnityEngine;
using System.Runtime.InteropServices;


/// <summary>
/// 适用于WSA(IOS未测试,应该可以, 安卓NDK方式应该也可以)的消息互发送
/// </summary>
public static class InterOp
{
    [return: MarshalAs(UnmanagedType.LPWStr)]
    public delegate string MessageOpData(int messageID, [MarshalAs(UnmanagedType.LPWStr)] string message);

    /// <summary>
    /// 获取原生代码中的方法指针,传递U3D中的处理委托
    /// </summary>
    /// <param name="del_MessageData"></param>
    /// <returns>原生代码中的方法指针</returns>
    [DllImport("InterOp", EntryPoint = "InitForU3D")]
    [return:MarshalAs(UnmanagedType.FunctionPtr)]
    private static extern MessageOpData InitForU3D([MarshalAs(UnmanagedType.FunctionPtr)] MessageOpData del_MessageData);



    private static MessageOpData NativeDelegate;


    /// <summary>
    /// 消息返回委托，注意需要在接收方法中按情况在U3D主线程中执行
    /// </summary>
    private static MessageOpData OnReceivedMessage;

    static InterOp()
    {
        try
        {
            NativeDelegate = InitForU3D(Fun_CallBack);
        }
        catch (System.Exception)
        {
            Debug.LogWarning("Not found native entry point of 'InitForU3D'");
        }
    }


    public static void Init(MessageOpData onReceivedMessage)
    {
        OnReceivedMessage = onReceivedMessage;
    }


    [AOT.MonoPInvokeCallback(typeof(MessageOpData))]
    [return: MarshalAs(UnmanagedType.LPWStr)]
    private static string Fun_CallBack(int messageID, [MarshalAs(UnmanagedType.LPWStr)] string message)
    {
        if (OnReceivedMessage != null)
        {
            return OnReceivedMessage(messageID, message);
        }
        return null;
    }


    /// <summary>
    /// 注意可能需要在原生UI的主线程执行
    /// </summary>
    /// <param name="messageID"></param>
    /// <param name="messageData"></param>
    /// <param name="messageStart"></param>
    /// <param name="messageLength"></param>
    /// <returns></returns>
    public static string SendMessageToNative(int messageID, string message)
    {
        if (NativeDelegate != null)
        {
            return NativeDelegate(messageID, message);
        }
        else
        {
            Debug.LogWarning("Not found native entry point of 'InitForU3D'");
            return null;
        }
    }
}
